package UST.UiFoundationTest.stepDefinitions;

import org.openqa.selenium.WebDriver;

import UST.UiFoundationTest.pageObjects.LoginPageObject;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepdefinition {

	private final WebDriver driver = Hooks.driver;
	public LoginPageObject login;


	@Given("I want to open cilory website")
	public void i_want_to_open_cilory_website() {
		login = new LoginPageObject(driver);
		login.clickLogin();
	}

	@When("i want to enter {string}")
	public void i_want_to_enter(String string) {
		login = new LoginPageObject(driver);
		login.enterDetails(string);
	}

	@When("i click submit button")
	public void i_click_submit_button() {
		login = new LoginPageObject(driver);
		login.submit();
	}

	@Then("i should enter otp number")
	public void i_should_enter_otp_number() {
		login = new LoginPageObject(driver);
		login.enterOtp();
	}

	@Then("i should be redirected to homepage")
	public void i_should_be_redirected_to_homepage() {
		login = new LoginPageObject(driver);
		login.submit();
	}
}
