package UST.UiFoundationTest.tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;

import UST.UiFoundationTest.base.Reusablefunctions;
import UST.UiFoundationTest.pageObjects.CartPageObject;
import UST.UiFoundationTest.pageObjects.SearchPageObject;


public class Basetest implements ITestListener {

public static WebDriver driver;
public Reusablefunctions reusableFunctions;
public CartPageObject cart;
public SearchPageObject search;

@BeforeClass
public void before() {
  driver = Reusablefunctions.invokeBrowser();
  reusableFunctions = new Reusablefunctions(driver);
  reusableFunctions.openBrowser("SiteURL");
  cart=new CartPageObject(driver);
  search=new SearchPageObject(driver);
}

//@AfterClass
//public void teardown() {
//	driver.quit();
//}
}










































//public static WebDriver driver;
//public Reusablefunctions reusableFunctions;
//
//  @BeforeTest
//   public void before() {
//       driver = Reusablefunctions.invokeBrowser();
//       reusableFunctions = new Reusablefunctions(driver);
//       reusableFunctions.openBrowser("SiteURL");
//      
//   }
//  @Test
//  public void openTestSite() {
//     
//     System.out.println("");
//  }
//  
//
//  @AfterClass
//  public void teardown() {
//	driver.quit();
//}