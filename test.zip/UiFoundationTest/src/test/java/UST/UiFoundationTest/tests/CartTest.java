package UST.UiFoundationTest.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(UST.UiFoundationTest.utilities.ExtentReportsListener.class)
public class CartTest extends Basetest {

	@Test(priority = 1)
    public void productClickTest() {   
        cart.clickFirstProduct();
        assertTrue(cart.checkProductTitle());
    }
	@Test(priority = 2)
    public void ClickProductSizeTest() {   
        cart.selectProductSize();
        assertTrue(cart.ProductSizeinfo().contains("34"));
    }
	@Test(priority = 3)
    public void ClickAddtoCartBtnTest() {   
        cart.clickAddtoCartBtn();    
        assertTrue(cart.productCountItems().contains("1"));
        cart.back();
    }
	@Test(priority = 4)
    public void secondProductClickTest() {   
        cart.clickSecondProduct();    
        assertTrue(cart.checkProductTitle());   
    }
	@Test(priority = 5)
    public void ClickProductSizeTest2() {   
        cart.selectProductSize();
        assertTrue(cart.ProductSizeinfo().contains("28"));
    }
	@Test(priority = 6)
    public void ClickAddtoCartBtn2Test() {   
        cart.clickAddtoCartBtn();    
        assertTrue(cart.productCountItems().contains("2"));
        cart.back();
    }
	@Test(priority = 7)
    public void ClickCartIconTest() {   
        cart.clickCartIcon();    
        assertEquals(driver.getCurrentUrl(), "https://www.cilory.com/quick-order");
    }
	@Test(priority = 8)
    public void RemoveItemTest() {   
        cart.clickRemoveBtn();   
        assertTrue(cart.cartCountItems().contains("1"));
    }
}
