package UST.UiFoundationTest.tests;

import static org.testng.Assert.assertEquals;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import UST.UiFoundationTest.utilities.Dataproviders;

@Listeners(UST.UiFoundationTest.utilities.ExtentReportsListener.class)
public class SearchTest extends Basetest{

	@Test(priority = 1,dataProvider = "search",dataProviderClass =Dataproviders.class )
    public void productClickTest(String... data) throws InterruptedException {   
       search.searchbtn(data[0]);
       assertEquals(driver.getCurrentUrl(), "https://www.cilory.com/164-men-shirts");    
    }
	
	@Test(priority = 2)
	public void productFliterTest() throws InterruptedException {
        search.Filtering();
        assertEquals(driver.getCurrentUrl(), "https://www.cilory.com/164-men-shirts#/categories-half_sleeves_casual_shirts/manufacturer-grunt/size-small/color-black/price-500_1000");
    }

}
