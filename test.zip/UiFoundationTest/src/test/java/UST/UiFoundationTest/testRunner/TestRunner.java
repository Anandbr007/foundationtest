package UST.UiFoundationTest.testRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		glue={"classpath:UST.UiFoundationTest.stepDefinitions"},
		tags ="@loginfeature",
		features={"classpath:features/Logintest.feature"},
		plugin= {"pretty","html:target/site/cucumber-report.html"}
		) 


public class TestRunner extends AbstractTestNGCucumberTests {

}












































