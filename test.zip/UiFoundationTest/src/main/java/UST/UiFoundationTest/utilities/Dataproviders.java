package UST.UiFoundationTest.utilities;

import java.io.IOException;

import org.testng.annotations.DataProvider;

import UST.UiFoundationTest.base.Fetchingexceldata;


public class Dataproviders {
	@DataProvider(name = "search")
	public String[][] searchData() throws IOException {
	    String path = System.getProperty("user.dir") + "\\src\\test\\resources\\testData\\data.xlsx";
	    String sheet = "Sheet1";
	    return Fetchingexceldata.excelHandling(path, sheet);
	}
}






































