package UST.UiFoundationTest.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import UST.UiFoundationTest.base.Reusablefunctions;

public class LoginPageObject {
	  WebDriver driver;
	    Reusablefunctions reusableFunctions;

	    public LoginPageObject(WebDriver driver) {
	        this.driver = driver;
	        reusableFunctions = new Reusablefunctions(driver); // Initialize reusableFunctions here
	        PageFactory.initElements(driver, this);
	    }
	
	
	By profile=By.xpath("//a[@class='icon-myacc navLink']");
	
	@FindBy(linkText = "emailOrMobile")
	WebElement login;
	
	@FindBy(linkText = "")
	WebElement phoneNumber;
	
	@FindBy(xpath = "(//div[@class='col s12'])[1]/button")
	WebElement submitbtn;
	
	@FindBy(id = "otp")
	WebElement otp;
	
	public void clickLogin() {
		Reusablefunctions.clickAction(profile, 10);
//		Reusablefunctions.clickOn(profile, 10);
		reusableFunctions.clickOn(login, 10);
	}
	
	public void enterDetails(String data) {
		reusableFunctions.sendText(phoneNumber, data);
	}
	public void submit() {
		reusableFunctions.clickOn(submitbtn, 10);
	}
	public void enterOtp() {
		try {
			Reusablefunctions.delay(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
