package UST.UiFoundationTest.pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import UST.UiFoundationTest.base.Reusablefunctions;

public class SearchPageObject {
	WebDriver driver;
	Reusablefunctions reusableFunctions;
	
	public SearchPageObject(WebDriver driver) {
		this.driver=driver;
		reusableFunctions=new Reusablefunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "search")
	WebElement searchBox;
	@FindBy(linkText = "Half Sleeves Casual Shirts")
	WebElement shirtTypes;
	@FindBy(linkText = "GRUNT")
	WebElement shirtBrand;
	@FindBy(linkText = "Small")
	WebElement shirtSize;
	@FindBy(linkText = "Black")
	WebElement shirtColour;
	@FindBy(linkText = "500 - 1000")
	WebElement Price;
	
	public void searchbtn(String string) throws InterruptedException {
		reusableFunctions.sendText(searchBox, string);		
		Reusablefunctions.delay(1);
	}
	public void clear() {
		searchBox.clear();
	}
	public void Filtering() throws InterruptedException {
		reusableFunctions.clickOn(shirtTypes, 10);
		Reusablefunctions.delay(1);
		reusableFunctions.clickOn(shirtBrand, 10);
		Reusablefunctions.delay(1);
		reusableFunctions.clickOn(shirtSize, 10);
		Reusablefunctions.delay(2);
		reusableFunctions.clickOn(shirtColour, 10);
		Reusablefunctions.delay(1);
		reusableFunctions.clickOn(Price, 10);
		Reusablefunctions.delay(2);
	}
}
