package UST.UiFoundationTest.pageObjects;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import UST.UiFoundationTest.base.Reusablefunctions;

public class CartPageObject {
	WebDriver driver;
	Reusablefunctions reusableFunctions;
	
	public CartPageObject(WebDriver driver) {
		this.driver=driver;
		reusableFunctions=new Reusablefunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "(//div[@class='col s3 l2'])[1]")
	WebElement product1;	
	@FindBy(xpath = "(//div[@class='col s3 l2'])[2]")
	WebElement product2;
	@FindBy(linkText = "S")
	WebElement selectSize;
	@FindBy(xpath = "//div[@class='sizeInfo']/span")
	WebElement sizeInfo;
	@FindBy(xpath = "//div[@class='col s6']/button")
	WebElement addtocartBtn;
	@FindBy(xpath = "(//a[@class='navLink'])[6]/div[2]")
	WebElement countItems;
	@FindBy(xpath = "//div[@class='col s12 pname']")
	WebElement productTitle;
	@FindBy(xpath = "(//a[@class='navLink'])[6]")
	WebElement cartIcon;
	@FindBy(xpath = "(//div[@class='col s6 center no-padding'])[2]/button")
	WebElement RemoveBtn;
	@FindBy(className = "badge-cart")
	WebElement cartCountItems;
	public void clickFirstProduct() {
		reusableFunctions.clickOn(product1,10);
		try {
			Reusablefunctions.delay(2);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void selectProductSize() {
		reusableFunctions.clickOn(selectSize,10);
	}
	public String ProductSizeinfo() {
		return	reusableFunctions.getTextofElement(sizeInfo);
	}
	public void clickAddtoCartBtn() {
		reusableFunctions.clickOn(addtocartBtn,10);
		try {
			Reusablefunctions.delay(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public String productCountItems() {
		return	reusableFunctions.getTextofElement(countItems);
	}
	public void clickSecondProduct() {
		reusableFunctions.clickOn(product2,10);
		try {
			Reusablefunctions.delay(2);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public boolean checkProductTitle() {	
		return productTitle.isDisplayed();
	}
	public void clickCartIcon() {
		reusableFunctions.clickOn(cartIcon,10);	
		try {
			Reusablefunctions.delay(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void clickRemoveBtn() {
		reusableFunctions.clickOn(RemoveBtn,10);
		try {
			Reusablefunctions.delay(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public String cartCountItems() {
		return	reusableFunctions.getTextofElement(cartCountItems);
	}
	
	public void back() {
		driver.navigate().back();
	}
}
