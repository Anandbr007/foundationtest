package mocktest1;

import java.io.File;


import org.hamcrest.Matchers;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

@Listeners(mocktest1.ExtentReportsListener.class)
public class mocktest {

	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	
	@Test
	public void getRequest() {
		String url="https://reqres.in/api/users?page=2";
		RestAssured.baseURI=url;
		RestAssured.given().relaxedHTTPSValidation()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().statusCode(200);
	}
	
	@Test
	public void postRequest() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payload.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users")
					.contentType(ContentType.JSON)
					.body(payload)
					.when()
					.post()
					.then()
					.assertThat()
					.statusCode(201);
	}
	@Test
	public void putRequest() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payloadPut.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users/2")
					.contentType(ContentType.JSON)
					.body(payload)
					.when().put()
					.then().assertThat()
					.statusCode(200);
	}
	
	@Test
	public void patchRequest() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payloadPatch.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users/2")
					.contentType(ContentType.JSON)
					.body(payload)
					.when().patch()
					.then().assertThat()
					.statusCode(200);			
	}
	
	@Test
	public void deleteRequest() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users/2")
					.contentType(ContentType.JSON)
					.when().delete()
					.then().assertThat()
					.statusCode(204);
				
	}
	@Test
	public void getRequestAndheader() {
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given().relaxedHTTPSValidation()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().header("Connection", "keep-alive").statusCode(200);
	}
	
	@Test
	public void getRequestQueryParam() {
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given().relaxedHTTPSValidation()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().statusCode(200);
	}
	
	@Test
	public void postRequestValidatetestcase() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payload.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users")
					.contentType(ContentType.JSON)
					.body(payload)
					.when()
					.post()
					.then()
					.assertThat()
					.statusCode(201)
					.contentType("application/json; charset=utf-8")
					.body("updatedAt",Matchers.startsWith("2024-04-17"));
					
	}

}
