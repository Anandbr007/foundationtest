package mocktest1;

import java.io.IOException;
//import java.io.ObjectInputFilter.Status;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import mainController.Reusable_class;


public class ExtentReportsListener implements ITestListener {
	static WebDriver driver; // WebDriver instance to capture screenshots
	public ExtentReports extent; // ExtentReports instance
	public ExtentTest test; // ExtentTest instance

	// Method to execute before the start of the test suite
	public void onStart(ITestContext context) {
		try {
			// Create an instance of ExtentReports
			extent = ExtentManager.createInstance();
		} catch (IOException e) {
			// Print stack trace if exception occurs during ExtentReports initialization
			e.printStackTrace();
		}
	}

	// Method to execute before each test method starts
	public void onTestStart(ITestResult result) {
		// Create a new test in the ExtentReports
		test = extent.createTest(result.getName());
	}

	// Method to execute after a test method passes
	public void onTestSuccess(ITestResult result) {
		// Log test as passed in ExtentReports
		test.log(Status.PASS, "Test case passed");
		// Add a label to the test with green color
		test.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
		// Define file path to capture screenshot
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filepath = System.getProperty("user.dir") + "//TestOutput//Screenshots" + folderName + "//" + testName
				+ "//" + testName + "_passed.png";
		try {
			// Take screenshot and add it to the ExtentReports
			Reusable_class.takeScreenShot(filepath);
			test.log(Status.PASS, (Markup) test.addScreenCaptureFromPath(filepath));
		} catch (Exception e) {
			// Print stack trace if exception occurs during screenshot capture
			e.printStackTrace();
		}
	}

	// Method to execute after a test method fails
	public void onTestFailure(ITestResult result) {
		// Log test as failed in ExtentReports
		test.log(Status.FAIL, "Test case Failed");
		// Add a label to the test with red color
		test.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));
		// Define file path to capture screenshot
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filepath = System.getProperty("user.dir") + "//TestOutput//Screenshots" + folderName + "//" + testName
				+ "//" + testName + "_failed.png";
		try {
			// Take screenshot and add it to the ExtentReports
			Reusable_class.takeScreenShot(filepath);
			test.log(Status.PASS, (Markup) test.addScreenCaptureFromPath(filepath));
		} catch (Exception e) {
			// Print stack trace if exception occurs during screenshot capture
			e.printStackTrace();
		}
	}

	// Method to execute after a test method is skipped
	public void onTestSkipped(ITestResult result) {
		// Log test as skipped in ExtentReports
		test.log(Status.SKIP, "Test case sKIPPED");
		// Add a label to the test with amber color
		test.log(Status.SKIP, MarkupHelper.createLabel(result.getName(), ExtentColor.AMBER));
	}

	// Method to execute after the completion of the test suite
	public void onFinish(ITestContext context) {
		// Flush ExtentReports to write the test results to the report
		extent.flush();
	}

}